# Some useful plot functions - saved in a separate module for cleanliness
# Michael Smales Aug 2022

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd


# define histogram plotting function
def hist_plot(chart_data, xlabel=None, ylabel=None, title=None, bin_step=None, maj_tick_step=None, min_tick_step=None, xlim=None):

    if xlim == None:
        max_val = chart_data.max()
        min_val = chart_data.min()
    else:
        max_val = xlim[1]
        min_val = xlim[0]

    if bin_step==None:
        bin_step = (max_val) / 10
    
    if maj_tick_step == None:
        maj_tick_step = bin_step

    # set bin edge and tick locations
    bin_edges = np.arange(0, max_val+ 2 * bin_step, bin_step)
    maj_tick_locn = np.arange(0, max_val+ 2 * bin_step, maj_tick_step)
    if min_tick_step != None:
        min_tick_locn = np.arange(0, max_val+ 2 * bin_step, min_tick_step)

    # set tick labels
    tick_labels = []
    if max_val > 1000:
        for label in maj_tick_locn:
            tick_labels.append("{:.1f}k".format(label/1000))
    elif max_val > 1000000:
        for label in maj_tick_locn:
            tick_labels.append("{:.1f}m".format(label/1000000))
    else:
        for label in maj_tick_locn:
            tick_labels.append("{:.2f}".format(label))


    # create histoagram plot
    fig = plt.figure(figsize=[8,5]);
    ax = fig.add_axes([0.1, 0.1, 0.9, 0.9]);
    ax.hist(chart_data, bins=bin_edges);

    # set x-axis ticks and labels, offsetting to center of each bin
    ax.set_xticks(maj_tick_locn, labels=tick_labels);
    if min_tick_step != None: 
        ax.set_xticks(min_tick_locn, minor=True);

    # add labels etc
    sns.despine()
    plt.xlabel(xlabel);
    plt.ylabel(ylabel);
    plt.title(title);

    # set xlimit
    ax.set_xlim(xlim)



# define function to reformat an axis as %
def tick_format(axis='x', format_type='pct'):
    format_string=""
    format_multiple=1
    if format_type=='pct':
        format_string = '{:.0f}%'
        format_multiple = 100
    if format_type=='k':
        format_string = '{:.1f}k'
        format_multiple = 0.001
    if format_type=='m':
        format_string = '{:.1f}m'
        format_multiple = 0.000001
    if format_type=='bn':
        format_string = '{:.1f}bn'
        format_multiple = 0.000000001

    if axis == 'x':
        xtick_locs, xtick_labels = plt.xticks()
        xtick_labels=[]
        for loc in xtick_locs:
            xtick_labels.append(format_string.format(loc*format_multiple))
        plt.xticks(ticks=xtick_locs, labels=xtick_labels);
    elif axis == 'y':
        ytick_locs, ytick_labels = plt.yticks()
        ytick_labels=[]
        for loc in ytick_locs:
            ytick_labels.append(format_string.format(loc*format_multiple))
        plt.yticks(ticks=ytick_locs, labels=ytick_labels);



# define function for plotting a (vertical) column chart with relative y axis
def rel_col_chart(chart_data, xlabel=None, ylabel=None, title=None, plot_order=None):
    base_color = sns.color_palette()[0]
    plt.figure(figsize=[8,5])

    sns.countplot(x=chart_data, color=base_color, order=plot_order);

    # set up y axis which goes up to 100%
    y_ticks_max = chart_data.value_counts().max() / chart_data.count()
    if y_ticks_max > 0.5:
        y_tick_step = 0.1
    else:
        y_tick_step = 0.05
    y_tick_props = np.arange(0, y_ticks_max, y_tick_step) 
    y_tick_names = ['{:0.0f}%'.format(v * 100) for v in y_tick_props]

    # set x and y labels
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)

    ax = plt.gca()
    ax.set_yticks(y_tick_props * chart_data.count(), labels=y_tick_names)
    sns.despine();



# define function for plotting a (horizontal) bar chart with relative x axis
def rel_bar_chart(chart_data, xlabel=None, ylabel=None, title=None, plot_order=[]):
    base_color = sns.color_palette()[0]
    plt.figure(figsize=[8,5])

    # convert plot order to a list if needed
    if isinstance(plot_order, pd.Index):
        plot_order = list(plot_order.values)

    if plot_order == []:
        sns.countplot(y=chart_data, color=base_color);
    else:
        sns.countplot(y=chart_data, color=base_color, order=plot_order);

    # set up y axis which goes up to 100%
    x_ticks_max = chart_data.value_counts().max() / chart_data.count()
    if x_ticks_max > 0.5:
        x_tick_step = 0.1
    else:
        x_tick_step = 0.05
    x_tick_props = np.arange(0, x_ticks_max, x_tick_step) 
    x_tick_names = ['{:0.0f}%'.format(v * 100) for v in x_tick_props]

    # set x and y labels
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)

    ax = plt.gca()
    ax.set_xticks(x_tick_props * chart_data.count(), labels=x_tick_names)
    sns.despine();

    # Logic to print the proportion text on the bars
    counts = chart_data.value_counts()
    if plot_order == []:
        plot_order = chart_data.unique()

    for i in range(len(plot_order)):
        count = counts.loc[plot_order[i]]
        # Convert count into a percentage, and then into string
        pct_string = '{:0.1f}%'.format(100 * count / chart_data.count())
        # Print the string value on the bar. 
        plt.text(count + counts.max()*0.01, i, pct_string, va='center')
